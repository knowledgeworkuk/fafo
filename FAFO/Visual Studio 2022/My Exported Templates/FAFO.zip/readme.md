﻿# FAFO

This Umbraco Site is a playground of experiments and examples and started life as a demo for a Meetup so no apologies!

Enjoy!

Andy Carlier
Knowledge Work